exports.handler = function(event, context) {
    context.succeed('Hello, World!');
    
    console.log(event)
};